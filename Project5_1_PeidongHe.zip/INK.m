function varargout = INK(varargin)
% INK MATLAB code for INK.fig
%      INK, by itself, creates a new INK or raises the existing
%      singleton*.
%
%      H = INK returns the handle to a new INK or the handle to
%      the existing singleton*.
%
%      INK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in INK.M with the given input arguments.
%
%      INK('Property','Value',...) creates a new INK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before INK_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to INK_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help INK

% Last Modified by GUIDE v2.5 22-Apr-2018 20:58:01

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @INK_OpeningFcn, ...
    'gui_OutputFcn',  @INK_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before INK is made visible.
function INK_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to INK (see VARARGIN)

% Choose default command line output for INK
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes INK wait for user response (see UIRESUME)
% uiwait(handles.figure1);


global drawing;
drawing =0;
set(gcf,'WindowButtonDownFcn',@mouseDown)
set(gcf,'WindowButtonMotionFcn',@mouseMove)
set(gcf,'WindowButtonUpFcn',@mouseUp)

global pnt
global Npnt
global Nstrk
global Npnt_all
Npnt_all=zeros(20,1);
pnt = zeros(1000,3,1000);
Npnt = 0;
Nstrk=0;
tic

% --- Outputs from this function are returned to the command line.
function varargout = INK_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in ClearButton.
function ClearButton_Callback(hObject, eventdata, handles)
% hObject    handle to ClearButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cla
global pnt
global Npnt
global Nstrk
global Npnt_all
Npnt_all=zeros(20,1);
pnt = zeros(1000,3,1000);
Npnt = 0;
Nstrk=0;


% --- Executes on button press in SaveButton.
function SaveButton_Callback(hObject, eventdata, handles)
% hObject    handle to SaveButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global pnt
global Npnt

if Npnt<1000
    pnt(Npnt+1:end,:) =[];
end

dlmwrite('InkData.txt',pnt)

function mouseDown(hObject, eventdata, handles)
global drawing
global Nstrk
global Npnt
drawing = 1;
Nstrk=Nstrk+1;
Npnt = 0;

function mouseUp(hObject, eventdata, handles)
global drawing
global Npnt_all
global Npnt
global Nstrk
drawing = 0;
if Nstrk>=1
    Npnt_all(Nstrk,1)=Npnt;
end

function mouseMove(hObject, eventdata, handles)
global drawing
global Npnt
global pnt
global Nstrk
if drawing
    C = get(gca,'CurrentPoint');
    if C(1,1)<1 && C(1,1)>0 && C(1,2)<1 && C(1,2)>0
        Npnt = Npnt+1;
        pnt(Npnt,1,Nstrk) = C(1,1);
        pnt(Npnt,2,Nstrk) = C(1,2);
        pnt(Npnt,3,Nstrk) = toc;
        plot(C(1,1),C(1,2),'k','marker','o','MarkerFaceColor','r')
        hold on
        xlim([0 1]); ylim([0 1]);
        set(gca,'XTick',[],'YTick',[])
        box on
    end
end



% --- Executes on button press in Recognisebutton.
function Recognisebutton_Callback(hObject, eventdata, handles)
% hObject    handle to Recognisebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDAA)
global Npnt
global pnt
global Nstrk
global Npnt_all
global x_lb
global x_ub
global y_lb
global y_ub
[ x_lb,x_ub,y_lb,y_ub ] = Bnd_box( pnt,Nstrk,Npnt_all );
f_all = Features_cl( Nstrk,Npnt_all,pnt );
f_all = f_all';
x = f_all;
%dlmwrite('dataTemp', f_all,'-append');
[q1,q2] = DATA;
[HH,score] = adaboost(q1,q2,x);
switch HH
    case 1
        set(handles.Recognition,'String','Number&NM');
    case -1
        set(handles.Recognition,'String','F&M');
end
set(handles.Scores,'String',score);

 
   
