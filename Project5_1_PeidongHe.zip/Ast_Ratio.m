function r = Ast_Ratio( x_lb,x_ub,y_lb,y_ub )
% Aspect ratio
r=(x_ub-x_lb)/(y_ub-y_lb);
end

